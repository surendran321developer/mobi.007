<!DOCTYPE html>
<html lang="en" dir="ltr">


<!-- Mirrored from themes.pixelstrap.com/fastkart/back-end/add-new-product.php by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 07 Apr 2025 10:11:06 GMT -->

<head>
    <!-- meta data -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description"
        content="Fastkart admin is super flexible, powerful, clean &amp; modern responsive bootstrap 5 admin template with unlimited possibilities.">
    <meta name="keywords"
        content="admin template, Fastkart admin template, dashboard template, flat admin template, responsive admin template, web app">
    <meta name="author" content="pixelstrap">
    <link rel="icon" href="assets/images/favicon.png" type="image/x-icon">
    <link rel="shortcut icon" href="assets/images/favicon.png" type="image/x-icon">
    <title>METS - Add New Product</title>

    <!-- Google font -->
    <link
        href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap"
        rel="stylesheet">

    <!-- Linear Icon css -->
    <link rel="stylesheet" href="assets/css/linearicon.css">

    <!-- Fontawesome css -->
    <link rel="stylesheet" type="text/css" href="assets/css/vendors/font-awesome.css">

    <!-- Themify icon css -->
    <link rel="stylesheet" type="text/css" href="assets/css/vendors/themify.css">

    <!--Dropzon css -->
    <link rel="stylesheet" type="text/css" href="assets/css/vendors/dropzone.css">

    <!-- Feather icon css-->
    <link rel="stylesheet" type="text/css" href="assets/css/vendors/feather-icon.css">

    <!-- remixicon css -->
    <link rel="stylesheet" type="text/css" href="assets/css/remixicon.css">

    <!-- Select2 css -->
    <link rel="stylesheet" type="text/css" href="assets/css/select2.min.css">

    <!-- Plugins css -->
    <link rel="stylesheet" type="text/css" href="assets/css/vendors/scrollbar.css">
    <link rel="stylesheet" type="text/css" href="assets/css/vendors/animate.css">
    <link rel="stylesheet" type="text/css" href="assets/css/vendors/chartist.css">
    <link rel="stylesheet" type="text/css" href="assets/css/vendors/date-picker.css">

    <!-- Bootstrap css -->
    <link rel="stylesheet" type="text/css" href="assets/css/vendors/bootstrap.css">

    <!-- Bootstrap-tag input css -->
    <link rel="stylesheet" type="text/css" href="assets/css/vendors/bootstrap-tagsinput.css">

    <!-- App css -->
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
</head>

<body>
    <!-- tap on top start -->
    <div class="tap-top">
        <span class="lnr lnr-chevron-up"></span>
    </div>
    <!-- tap on tap end -->

    <!-- page-wrapper start -->
    <div class="page-wrapper compact-wrapper" id="pageWrapper">
        <!-- Page Header Start-->
        <div class="page-header">
            <div class="header-wrapper m-0">
                <div class="header-logo-wrapper p-0">
                    <div class="logo-wrapper">
                        <a href="index.php">
                            <img class="img-fluid main-logo" src="assets/images/logo/1.png" alt="logo">
                            <img class="img-fluid white-logo" src="assets/images/logo/1-white.png" alt="logo">
                        </a>
                    </div>
                    <div class="toggle-sidebar">
                        <i class="status_toggle middle sidebar-toggle" data-feather="align-center"></i>
                        <a href="index.php">
                            <img src="assets/images/logo/1.png" class="img-fluid" alt="">
                        </a>
                    </div>
                </div>

                <form class="form-inline search-full" action="javascript:void(0)" method="get">
                    <div class="form-group w-100">
                        <div class="Typeahead Typeahead--twitterUsers">
                            <div class="u-posRelative">
                                <input class="demo-input Typeahead-input form-control-plaintext w-100" type="text"
                                    placeholder="Search Fastkart .." name="q" title="" autofocus>
                                <i class="close-search" data-feather="x"></i>
                                <div class="spinner-border Typeahead-spinner" role="status">
                                    <span class="sr-only">Loading...</span>
                                </div>
                            </div>
                            <div class="Typeahead-menu"></div>
                        </div>
                    </div>
                </form>
                <div class="nav-right col-6 pull-right right-header p-0">
                    <ul class="nav-menus">
                        <li>
                            <span class="header-search">
                                <i class="ri-search-line"></i>
                            </span>
                        </li>
                        <li class="onhover-dropdown">
                            <div class="notification-box">
                                <i class="ri-notification-line"></i>
                                <span class="badge rounded-pill badge-theme">4</span>
                            </div>
                            <ul class="notification-dropdown onhover-show-div">
                                <li>
                                    <i class="ri-notification-line"></i>
                                    <h6 class="f-18 mb-0">Notitications</h6>
                                </li>
                                <li>
                                    <p>
                                        <i class="fa fa-circle me-2 font-primary"></i>Delivery processing <span
                                            class="pull-right">10 min.</span>
                                    </p>
                                </li>
                                <li>
                                    <p>
                                        <i class="fa fa-circle me-2 font-success"></i>Order Complete<span
                                            class="pull-right">1 hr</span>
                                    </p>
                                </li>
                                <li>
                                    <p>
                                        <i class="fa fa-circle me-2 font-info"></i>Tickets Generated<span
                                            class="pull-right">3 hr</span>
                                    </p>
                                </li>
                                <li>
                                    <p>
                                        <i class="fa fa-circle me-2 font-danger"></i>Delivery Complete<span
                                            class="pull-right">6 hr</span>
                                    </p>
                                </li>
                                <li>
                                    <a class="btn btn-primary" href="javascript:void(0)">Check all notification</a>
                                </li>
                            </ul>
                        </li>

                        <li>
                            <div class="mode">
                                <i class="ri-moon-line"></i>
                            </div>
                        </li>
                        <li class="profile-nav onhover-dropdown pe-0 me-0">
                            <div class="media profile-media">
                                <img class="user-profile rounded-circle" src="assets/images/users/4.jpg" alt="">
                                <div class="user-name-hide media-body">
                                    <span>Emay Walter</span>
                                    <p class="mb-0 font-roboto">Admin<i class="middle ri-arrow-down-s-line"></i></p>
                                </div>
                            </div>
                            <ul class="profile-dropdown onhover-show-div">
                                <li>
                                    <a href="order-list.php">
                                        <i data-feather="users"></i>
                                        <span>Orders</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="order-list.php">
                                        <i data-feather="archive"></i>
                                        <span>Orders</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="order-list.php">
                                        <i data-feather="phone"></i>
                                        <span>Orders</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="profile-setting.php">
                                        <i data-feather="settings"></i>
                                        <span>Settings</span>
                                    </a>
                                </li>
                                <li>
                                    <a data-bs-toggle="modal" data-bs-target="#staticBackdrop"
                                        href="javascript:void(0)">
                                        <i data-feather="log-out"></i>
                                        <span>Log out</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- Page Header Ends-->

        <!-- Page Body start -->
        <div class="page-body-wrapper">
            <!-- Page Sidebar Start-->
            <div class="sidebar-wrapper">
                <div id="sidebarEffect"></div>
                <div>
                    <div class="logo-wrapper logo-wrapper-center">
                        <a href="index.php" data-bs-original-title="" title="">
                            <img class="img-fluid for-white" src="assets/images/logo/full-white.png" alt="logo">
                        </a>
                        <div class="back-btn">
                            <i class="fa fa-angle-left"></i>
                        </div>
                        <div class="toggle-sidebar">
                            <i class="ri-apps-line status_toggle middle sidebar-toggle"></i>
                        </div>
                    </div>
                    <div class="logo-icon-wrapper">
                        <a href="index.php">
                            <img class="img-fluid main-logo main-white" src="assets/images/logo/1-white.png" alt="logo">
                            <img class="img-fluid main-logo main-dark" src="assets/images/logo/logo-white.png"
                                alt="logo">
                        </a>
                    </div>


                    <?php include_once "nav.php" ?>



                </div>
            </div>
            <!-- Page Sidebar Ends-->

            <div class="page-body">

                <!-- New Product Add Start -->
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="row">
                                <div class="col-sm-8 m-auto">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="card-header-2">
                                                <h5>Product Information</h5>
                                            </div>


                                            <form class="theme-form theme-form-2 mega-form" method="POST"
                                                action="process_product.php" enctype="multipart/form-data">
                                                <!-- Success/Error Messages -->
                                             
                                                <!-- Product Name -->
                                              <div class="mb-4 row align-items-center">
                                                    <label class="form-label-title col-sm-3 mb-0">Product Name</label>
                                                    <div class="col-sm-9">
                                                        <input class="form-control" type="text" name="product_name"
                                                            placeholder="Product Name" required>
                                                    </div>
                                                </div>


                                                <!-- Product Images -->
                                                <div class="mb-4 row align-items-center">
                                                    <label
                                                        class="col-sm-3 col-form-label form-label-title">Images</label>
                                                    <div class="col-sm-9">
                                                        <input class="form-control form-choose" type="file"
                                                            name="product_images[]" id="formFile" multiple
                                                            accept="image/*">
                                                        <small class="text-muted">You can select multiple images
                                                            (JPEG, PNG, JPG, max 5MB each)</small>
                                                    </div>
                                                </div>

                                                <!-- Product Category -->
                                                <div class="mb-4 row align-items-center">
                                                    <label
                                                        class="col-sm-3 col-form-label form-label-title">Category</label>
                                                    <div class="col-sm-9">
                                                        <select class="js-example-basic-single w-100" name="category"
                                                            required>
                                                            
            <option value="" disabled selected>
                Select Category
            </option>

            <!-- Mobile -->
            <option value="Mobiles">
                Mobiles
            </option>

            <!-- iPhone -->
            <option value="iPhone">
                iPhone
            </option>

            <!-- OnePlus -->
            <option value="OnePlus">
                OnePlus
            </option>

            <!-- Android Phones -->
            <option value="Android Phones">
                Android Phones
            </option>

            <!-- Earbuds -->
            <option value="Earbuds">
                Earbuds
            </option>

            <!-- Headphones -->
            <option value="Headphones">
                Headphones
            </option>

            <!-- Speakers -->
            <option value="Speakers">
                Speakers
            </option>

            <!-- Chargers -->
            <option value="Chargers">
                Chargers
            </option>

            <!-- Cables -->
            <option value="Cables">
                Cables
            </option>

            <!-- Power Banks -->
            <option value="Power Banks">
                Power Banks
            </option>

            <!-- Smart Watches -->
            <option value="Smart Watches">
                Smart Watches
            </option>

            <!-- Phone Cases -->
            <option value="Phone Cases">
                Phone Cases
            </option>

            <!-- Screen Guards -->
            <option value="Screen Guards">
                Screen Guards
            </option>

            <!-- Mobile Accessories -->
            <option value="Mobile Accessories">
                Mobile Accessories
            </option>

            <!-- Apple Accessories -->
            <option value="Apple Accessories">
                Apple Accessories
            </option>

            <!-- Gaming Accessories -->
            <option value="Gaming Accessories">
                Gaming Accessories
            </option>

            <!-- Projectors -->
            <option value="Projectors">
                Projectors
            </option>

            <!-- Other -->
             <option value="Other">
                Other
             </option>
                                                        </select>
                                                        <input type="text" >
                                                    </div>
                                                </div>

                                                <!-- Product Brand -->
                                                <div class="mb-4 row align-items-center">
                                                    <label
                                                        class="col-sm-3 col-form-label form-label-title">Brand</label>
                                                    <div class="col-sm-9">
                                                        <select class="js-example-basic-single w-100" name="brand"
                                                            required>
                                                            <option value="" disabled selected>Select Brand</option>
                                                            <option value="Havells">Havells</option>
                                                            <option value="Anchor">Anchor</option>
                                                            <option value="Legrand">Legrand</option>
                                                            <option value="Finolex">Finolex</option>
                                                            <option value="Polycab">Polycab</option>
                                                            <option value="Crompton">Crompton</option>
                                                            <option value="Bajaj">Bajaj</option>
                                                        </select>
                                                    </div>
                                                </div>


                                                <!-- Product Price -->
                                                <div class="mb-4 row align-items-center">
                                                    <div class="card-header-2">
                                                        <h5>Product Price</h5>
                                                    </div>
                                                    <label class="col-sm-3 form-label-title">Price (₹)</label>
                                                    <div class="col-sm-9">
                                                        <input class="form-control" type="number" name="price"
                                                            placeholder="0.00" step="0.01" min="0" required>
                                                    </div>
                                                </div>


                                                <!-- Product Quantity -->
                                                <div class="mb-4 row align-items-center">
                                                    <label class="col-sm-3 form-label-title">Quantity</label>
                                                    <div class="col-sm-9">
                                                        <input class="form-control" type="number" name="quantity"
                                                            placeholder="0" min="0" required>
                                                    </div>
                                                </div>


                                                <!-- Product Description -->
                                                <div class="card-header-2">
                                                    <h5>Description</h5>
                                                </div>
                                                <div class="row">
                                                    <div class="col-12">
                                                        <div class="row">
                                                            <label class="form-label-title col-sm-3 mb-0">Product
                                                                Description</label>
                                                            <div class="col-sm-9">
                                                                <textarea class="form-control" name="description"
                                                                    rows="5" required></textarea>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>


                                                <!-- Product Status (Hidden by default - Active) -->
                                                <input type="hidden" name="status" value="1">

                                                <!-- Submit Button -->
                                                <div class="d-flex justify-content-end mt-5">
                                                    <button type="submit" name="submit_product"
                                                        class="btn btn-solid">Submit Product</button>
                                                </div>
                                            </form>


</body>

</html>
</div>
</div>









</div>
</div>
</div>
</div>
<!-- New Product Add End -->

<!-- footer Start -->
<div class="container-fluid">
    <footer class="footer">
        <div class="row">
            <div class="col-md-12 footer-copyright text-center">
                <p class="mb-0">Copyright 2022 © METS theme by pixelstrap</p>
            </div>
        </div>
    </footer>
</div>
<!-- footer En -->
</div>
<!-- Container-fluid End -->
</div>
<!-- Page Body End -->
</div>
<!-- page-wrapper End -->

<!-- Modal Start -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
    aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog  modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body">
                <h5 class="modal-title" id="staticBackdropLabel">Logging Out</h5>
                <p>Are you sure you want to log out?</p>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

                <div class="button-box">
                    <button type="button" class="btn btn--no" data-bs-dismiss="modal">No</button>
                    <button type="button" class="btn  btn--yes btn-primary">Yes</button>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal End -->

<!-- latest js -->
<script src="assets/js/jquery-3.6.0.min.js"></script>

<!-- Bootstrap js -->
<script src="assets/js/bootstrap/bootstrap.bundle.min.js"></script>

<!-- feather icon js -->
<script src="assets/js/icons/feather-icon/feather.min.js"></script>
<script src="assets/js/icons/feather-icon/feather-icon.js"></script>

<!-- scrollbar simplebar js -->
<script src="assets/js/scrollbar/simplebar.js"></script>
<script src="assets/js/scrollbar/custom.js"></script>

<!-- Sidebar js -->
<script src="assets/js/config.js"></script>

<!-- bootstrap tag-input js -->
<script src="assets/js/bootstrap-tagsinput.min.js"></script>
<script src="assets/js/sidebar-menu.js"></script>

<!-- customizer js -->
<script src="assets/js/customizer.js"></script>

<!--Dropzon js -->
<script src="assets/js/dropzone/dropzone.js"></script>
<script src="assets/js/dropzone/dropzone-script.js"></script>

<!-- Plugins js -->
<script src="assets/js/notify/bootstrap-notify.min.js"></script>
<script src="assets/js/notify/index.js"></script>

<!-- ck editor js -->
<script src="assets/js/ckeditor.js"></script>
<script src="assets/js/ckeditor-custom.js"></script>

<!-- select2 js -->
<script src="assets/js/select2.min.js"></script>
<script src="assets/js/select2-custom.js"></script>

<!-- sidebar effect -->
<script src="assets/js/sidebareffect.js"></script>

<!-- Theme js -->
<script src="assets/js/script.js"></script>

</body>


<!-- Mirrored from themes.pixelstrap.com/fastkart/back-end/add-new-product.php by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 07 Apr 2025 10:11:07 GMT -->

</html>
