<?php
include_once 'db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['product_id'])) {
    $product_id = (int)$_POST['product_id'];

    $stmt = $conn->prepare("UPDATE products SET status = 0 WHERE id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();

    $stmt->close();
    $conn->close();

    // Redirect back to the main product list
    header("Location: products.php"); // change to your product list file
    exit();
}
?>
