<?php
$host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';

if ($host === 'localhost' || $host === '127.0.0.1') {
    $servername = 'localhost';
    $username   = 'root';
    $password   = '';
    $dbname     = 'mobill_world_db';
} else {
    $servername = 'localhost';
    $username   = 'u289349176_mobi123';
    $password   = 'Arun@12514';
    $dbname     = 'u289349176_mobi';
}

mysqli_report(MYSQLI_REPORT_OFF);
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("DB connection failed: " . $conn->connect_error);
}
