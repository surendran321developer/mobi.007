<?php
session_start();


include_once 'db.php';

// Process form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_product'])) {
    // Get form data with validation
    $product_name = $conn->real_escape_string(trim($_POST['product_name']));
    $category = $conn->real_escape_string($_POST['category']);
    $brand = $conn->real_escape_string($_POST['brand']);
    $price = floatval($_POST['price']);
    $quantity = intval($_POST['quantity']);
    $description = $conn->real_escape_string(trim($_POST['description']));
    $status = 1; // 1 = Active, 0 = Deleted

    // Validate required fields
    if (empty($product_name) || empty($category) || empty($brand) || empty($description) || $price <= 0) {
        $_SESSION['error_message'] = "Please fill all required fields with valid data!";
        header("Location: add-new-product.php");
        exit();
    }

    // Handle multiple image uploads
    $image_paths = [];
    if (!empty($_FILES['product_images']['name'][0])) {
        $target_dir = "uploads/products/";
        if (!is_dir($target_dir)) {
            
            mkdir($target_dir, 0755, true);
        }

        $allowed_types = ['image/jpeg', 'image/png', 'image/jpg'];
        $max_size = 5 * 1024 * 1024; // 5MB

        foreach ($_FILES['product_images']['tmp_name'] as $key => $tmp_name) {
            $file_name = $_FILES['product_images']['name'][$key];
            $file_size = $_FILES['product_images']['size'][$key];
            $file_tmp = $_FILES['product_images']['tmp_name'][$key];
            $file_type = $_FILES['product_images']['type'][$key];

            // Validate image
            $check = getimagesize($file_tmp);
            if ($check === false || !in_array($file_type, $allowed_types) || $file_size > $max_size) {
                $_SESSION['error_message'] = "Invalid image file or file too large (max 5MB)!";
                header("Location: add-new-product.php");
                exit();
            }

            // Generate unique filename
            $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
            $new_filename = uniqid() . '_' . time() . '.' . $file_ext;
            $target_file = $target_dir . $new_filename;

            if (move_uploaded_file($file_tmp, $target_file)) {
                $image_paths[] = $target_file;
            }
        }
    }

    // Convert image paths to JSON
    $image_path = !empty($image_paths) ? json_encode($image_paths) : NULL;

    // Insert into database
    $sql = "INSERT INTO products (
        product_name, 
        category, 
        brand, 
        price, 
        quantity, 
        description, 
        image_path, 
        status, 
        created_at, 
        updated_at
    ) VALUES (
        '$product_name', 
        '$category', 
        '$brand', 
        '$price', 
        '$quantity', 
        '$description', 
        '$image_path', 
        '$status', 
        NOW(), 
        NOW()
    )";

    if ($conn->query($sql)) {
        $_SESSION['success_message'] = "Product added successfully!";
        header("Location: products.php");
        exit();
    } else {
        $_SESSION['error_message'] = "Error: " . $conn->error;
        header("Location: add-new-product.php");
        exit();
    }
}

$conn->close();
?>