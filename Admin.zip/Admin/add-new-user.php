<?php
header('Location: order-list.php');
exit;
