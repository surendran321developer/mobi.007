<?php

include_once 'db.php';


/* =========================================================
   ONLY POST REQUEST
========================================================= */

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    echo "Invalid request";
    exit;
}


/* =========================================================
   GET FORM DATA
========================================================= */

$orderId = trim((string)($_POST['order_id'] ?? ''));

$productId = isset($_POST['product_id'])
    ? (int) $_POST['product_id']
    : 0;

$productName = trim((string)($_POST['product_name'] ?? ''));

$productPrice = trim((string)($_POST['product_price'] ?? '0'));

$customerName = trim((string)($_POST['customer_name'] ?? ''));

$phoneNumber = trim((string)($_POST['phone_number'] ?? ''));

$customerAddress = trim((string)($_POST['customer_address'] ?? ''));

$paymentMethod = trim((string)($_POST['payment_method'] ?? ''));


/* =========================================================
   REQUIRED FIELD VALIDATION
========================================================= */

if (
    $orderId === '' ||
    $productName === '' ||
    $customerName === '' ||
    $phoneNumber === '' ||
    $customerAddress === '' ||
    $paymentMethod === ''
) {

    echo "Please fill all required fields.";
    exit;
}


/* =========================================================
   PAYMENT METHOD VALIDATION
========================================================= */

if (!in_array($paymentMethod, ['cod', 'online'], true)) {

    echo "Invalid payment method.";
    exit;
}


/* =========================================================
   CHECK DATABASE CONNECTION
========================================================= */

if (!$conn || $conn->connect_error) {

    echo "Database connection failed.";
    exit;
}


/* =========================================================
   GET ACTUAL PRODUCT DETAILS
   FROM DATABASE
========================================================= */

if ($productId > 0) {

    $productStmt = $conn->prepare("
        SELECT
            id,
            product_name,
            price,
            status
        FROM products
        WHERE id = ?
        LIMIT 1
    ");

    if (!$productStmt) {

        echo "Product query failed: " . $conn->error;

        $conn->close();

        exit;
    }


    $productStmt->bind_param(
        "i",
        $productId
    );


    if (!$productStmt->execute()) {

        echo "Product check failed: " . $productStmt->error;

        $productStmt->close();
        $conn->close();

        exit;
    }


    $productResult = $productStmt->get_result();


    if (!$productRow = $productResult->fetch_assoc()) {

        echo "Product not found.";

        $productStmt->close();
        $conn->close();

        exit;
    }


    /* =====================================================
       CHECK PRODUCT STATUS
    ===================================================== */

    if ((int)$productRow['status'] !== 1) {

        echo "This product is currently unavailable.";

        $productStmt->close();
        $conn->close();

        exit;
    }


    /* =====================================================
       USE DATABASE PRODUCT NAME
    ===================================================== */

    $productName = trim(
        (string)$productRow['product_name']
    );


    /* =====================================================
       USE DATABASE PRODUCT PRICE
    ===================================================== */

    $productPrice = is_numeric($productRow['price'])
        ? (float)$productRow['price']
        : 0.00;


    $productStmt->close();
}


/* =========================================================
   PRODUCT ID NOT AVAILABLE
   USE FORM PRICE
========================================================= */

else {

    $productPrice = is_numeric($productPrice)
        ? (float)$productPrice
        : 0.00;
}


/* =========================================================
   CLEAN CUSTOMER DATA
========================================================= */

$customerName = preg_replace('/\s+/', ' ', $customerName);
$phoneNumber = preg_replace('/\s+/', ' ', $phoneNumber);


/* =========================================================
   CHECK ORDER ID ALREADY EXISTS
========================================================= */

$checkStmt = $conn->prepare("
    SELECT id
    FROM orders
    WHERE order_id = ?
    LIMIT 1
");


if (!$checkStmt) {

    echo "Order ID check failed: " . $conn->error;

    $conn->close();

    exit;
}


$checkStmt->bind_param(
    "s",
    $orderId
);


if (!$checkStmt->execute()) {

    echo "Order ID check failed: " . $checkStmt->error;

    $checkStmt->close();
    $conn->close();

    exit;
}


$checkResult = $checkStmt->get_result();


/* =========================================================
   DUPLICATE ORDER ID
========================================================= */

if ($checkResult->num_rows > 0) {

    echo "Order ID already exists. Please refresh the page and try again.";

    $checkStmt->close();
    $conn->close();

    exit;
}


$checkStmt->close();


/* =========================================================
   INSERT ORDER
========================================================= */

$sql = "
    INSERT INTO orders
    (
        order_id,
        product_id,
        product_name,
        product_price,
        customer_name,
        phone_number,
        customer_address,
        payment_method
    )
    VALUES
    (?, ?, ?, ?, ?, ?, ?, ?)
";


$stmt = $conn->prepare($sql);


/* =========================================================
   PREPARE ERROR
========================================================= */

if (!$stmt) {

    echo "Order save failed: " . $conn->error;

    $conn->close();

    exit;
}


/* =========================================================
   BIND PARAMETERS
========================================================= */

$stmt->bind_param(
    "sisdssss",
    $orderId,
    $productId,
    $productName,
    $productPrice,
    $customerName,
    $phoneNumber,
    $customerAddress,
    $paymentMethod
);


/* =========================================================
   EXECUTE INSERT
========================================================= */

if (!$stmt->execute()) {

    echo "Order save failed: " . $stmt->error;

    $stmt->close();
    $conn->close();

    exit;
}


/* =========================================================
   SUCCESS
========================================================= */

echo "SUCCESS";


/* =========================================================
   CLOSE
========================================================= */

$stmt->close();

$conn->close();

exit;

?>