 <!-- footer start-->
 <div class="container-fluid">
                    <footer class="footer">
                        <div class="row">
                            <div class="col-md-12 footer-copyright text-center">
                                <p class="mb-0">Copyright 2025 © Mobi theme by METS</p>
                            </div>
                        </div>
                    </footer>
                </div>
                <!-- footer End-->