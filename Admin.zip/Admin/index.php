
<?php
session_start();

$loginMessage = '';

include_once 'db.php'; // Your database connection in db.php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['admin_name'] ?? '';
    $email = $_POST['admin_email'] ?? '';
    $password = $_POST['admin_password'] ?? '';

    $stmt = $conn->prepare("SELECT * FROM admin_users WHERE name = ? AND email = ? AND password = ?");
    $stmt->bind_param("sss", $name, $email, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        header("Location: order-list.php");
        exit();
    } else {
        $loginMessage = "Invalid credentials. Please try again.";
    }

    $stmt->close();
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
<?php include_once "head.php" ?>
<body>
    <!-- tap on top start-->
    <div class="tap-top">
        <span class="lnr lnr-chevron-up"></span>
    </div>
    <!-- tap on tap end-->

    <div class="page-wrapper compact-wrapper" id="pageWrapper">
        <div class="page-header">
            <div class="header-wrapper m-0">
                <div class="nav-right col-6 pull-right right-header p-0"></div>
            </div>
        </div>

        <div class="page-body-wrapper">
            <div class="sidebar-wrapper">
                <div id="sidebarEffect"></div>
                <div>
                    <div class="logo-wrapper logo-wrapper-center">
                        <a href="index.php">
                            <img class="img-fluid for-white" src="assets/images/logo/full-white.png" alt="logo">
                        </a>
                        <div class="back-btn"><i class="fa fa-angle-left"></i></div>
                        <div class="toggle-sidebar"><i class="ri-apps-line status_toggle middle sidebar-toggle"></i></div>
                    </div>
                    <div class="logo-icon-wrapper">
                        <a href="index.php">
                            <img class="img-fluid main-logo main-white" src="assets/images/logo/1-white.png" alt="logo">
                            <img class="img-fluid main-logo main-dark" src="assets/images/logo/logo-white.png" alt="logo">
                        </a>
                    </div>
                    <?php include_once "nav1.php" ?>
                </div>
            </div>

            <div class="page-body">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="title-header option-title">
                                        <h5>Admin Login</h5>
                                    </div>

                                    <?php if (!empty($loginMessage)) : ?>
                                        <div class="alert alert-danger" role="alert">
                                            <?= $loginMessage ?>
                                        </div>
                                    <?php endif; ?>

                                    <form class="theme-form theme-form-2 mega-form" action="" method="POST">
                                        <div class="row">
                                            <div class="mb-4 row align-items-center">
                                                <label class="form-label-title col-sm-2 mb-0">First Name</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" type="text" name="admin_name" required>
                                                </div>
                                            </div>

                                            <div class="mb-4 row align-items-center">
                                                <label class="form-label-title col-sm-2 mb-0">Email Address</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" type="email" name="admin_email" required>
                                                </div>
                                            </div>

                                            <div class="mb-4 row align-items-center">
                                                <label class="form-label-title col-sm-2 mb-0">Password</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" type="password" name="admin_password" required>
                                                </div>
                                            </div>

                                            <div class="mb-4 row">
                                                <div class="col-sm-10 offset-sm-2">
                                                    <button type="submit" class="btn btn-primary">Login</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php include_once "footer.php" ?>

        
    </div>

    <!-- JS and scripts -->
    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <script src="assets/js/bootstrap/bootstrap.bundle.min.js"></script>
    <script src="assets/js/icons/feather-icon/feather.min.js"></script>
    <script src="assets/js/icons/feather-icon/feather-icon.js"></script>
    <script src="assets/js/scrollbar/simplebar.js"></script>
    <script src="assets/js/scrollbar/custom.js"></script>
    <script src="assets/js/config.js"></script>
    <script src="assets/js/sidebar-menu.js"></script>
    <script src="assets/js/customizer.js"></script>
    <script src="assets/js/dropzone/dropzone.js"></script>
    <script src="assets/js/dropzone/dropzone-script.js"></script>
    <script src="assets/js/notify/bootstrap-notify.min.js"></script>
    <script src="assets/js/notify/index.js"></script>
    <script src="assets/js/script.js"></script>
</body>
</html>
