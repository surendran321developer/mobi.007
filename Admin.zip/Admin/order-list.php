<?php
include_once 'db.php';

$deleteError = '';
$deleteSuccess = isset($_GET['deleted']) && $_GET['deleted'] === '1';

$createTableSql = "
    CREATE TABLE IF NOT EXISTS customer_orders (
        id INT(11) NOT NULL AUTO_INCREMENT,
        product_id INT(11) DEFAULT NULL,
        product_name VARCHAR(255) NOT NULL,
        product_price DECIMAL(10,2) DEFAULT 0.00,
        quantity INT(11) NOT NULL DEFAULT 1,
        customer_name VARCHAR(120) NOT NULL,
        phone_number VARCHAR(25) NOT NULL,
        customer_address TEXT NOT NULL,
        payment_method VARCHAR(20) NOT NULL DEFAULT 'cod',
        order_note TEXT DEFAULT NULL,
        order_status VARCHAR(30) NOT NULL DEFAULT 'Pending',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_customer_orders_created_at (created_at),
        KEY idx_customer_orders_status (order_status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
";
$conn->query($createTableSql);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_order'])) {
    $orderId = (int) ($_POST['order_id'] ?? 0);
    if ($orderId > 0) {
        $stmt = $conn->prepare("DELETE FROM customer_orders WHERE id = ?");
        if ($stmt) {
            $stmt->bind_param("i", $orderId);
            if ($stmt->execute()) {
                $stmt->close();
                header('Location: order-list.php?deleted=1');
                exit;
            }
            $deleteError = 'Order delete failed. Please try again.';
            $stmt->close();
        } else {
            $deleteError = 'Order delete failed. Please check database connection.';
        }
    } else {
        $deleteError = 'Invalid order selected.';
    }
}

$orders = $conn->query("SELECT * FROM customer_orders ORDER BY created_at DESC");

function e($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<?php include_once "head.php"; ?>

<style>
    .admin-page-title {
        color: #222;
        font-size: 18px;
        font-weight: 700;
        margin-left: 18px;
        white-space: nowrap;
    }

    .orders-mobile {
        display: none;
    }

    .order-card {
        background: #fff;
        border: 1px solid #eee;
        border-radius: 8px;
        box-shadow: 0 4px 14px rgba(0, 0, 0, 0.06);
        margin-bottom: 14px;
        padding: 14px;
    }

    .order-card h6 {
        color: #222;
        font-size: 15px;
        font-weight: 700;
        line-height: 1.4;
        margin: 0 0 10px;
    }

    .order-card p {
        color: #555;
        font-size: 13px;
        line-height: 1.45;
        margin: 4px 0;
        overflow-wrap: anywhere;
    }

    .order-card .btn {
        margin-top: 10px;
        width: 100%;
    }

    .order-alert {
        border-radius: 8px;
        margin-bottom: 15px;
    }

    @media (max-width: 767px) {
        .admin-page-title {
            font-size: 15px;
            margin-left: 10px;
        }

        .orders-table-wrap {
            display: none;
        }

        .orders-mobile {
            display: block;
        }

        .card-table .card-body {
            padding: 14px;
        }

        .title-header h5 {
            font-size: 16px;
        }

        .page-body {
            padding: 12px !important;
        }
    }
</style>

<body>
    <div class="tap-top">
        <span class="lnr lnr-chevron-up"></span>
    </div>

    <div class="page-wrapper compact-wrapper" id="pageWrapper">
        <div class="page-header">
            <div class="header-wrapper m-0">
                <div class="header-logo-wrapper p-0">
                    <div class="logo-wrapper">
                        <a href="index.php">
                            <img class="img-fluid main-logo" src="assets/images/logo/1.png" alt="logo">
                            <img class="img-fluid white-logo" src="assets/images/logo/1-white.png" alt="logo">
                        </a>
                    </div>
                    <div class="toggle-sidebar">
                        <i class="status_toggle middle sidebar-toggle" data-feather="align-center"></i>
                        <a href="index.php">
                            <img src="assets/images/logo/1.png" class="img-fluid" alt="">
                        </a>
                    </div>
                </div>
                <div class="admin-page-title">Admin Panel</div>

                <div class="nav-right col-6 pull-right right-header p-0">
                    <ul class="nav-menus">
                        <li>
                            <div class="mode">
                                <i class="ri-moon-line"></i>
                            </div>
                        </li>
                        <li class="profile-nav onhover-dropdown pe-0 me-0">
                            <div class="media profile-media">
                                <img class="user-profile rounded-circle" src="assets/images/users/4.jpg" alt="">
                                <div class="user-name-hide media-body">
                                    <span>Mobi World</span>
                                    <p class="mb-0 font-roboto">Admin<i class="middle ri-arrow-down-s-line"></i></p>
                                </div>
                            </div>
                            <ul class="profile-dropdown onhover-show-div">
                                <li>
                                    <a href="order-list.php">
                                        <i data-feather="archive"></i>
                                        <span>Orders</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="profile-setting.php">
                                        <i data-feather="settings"></i>
                                        <span>Settings</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="page-body-wrapper">
            <div class="sidebar-wrapper">
                <div id="sidebarEffect"></div>
                <div>
                    <div class="logo-wrapper logo-wrapper-center">
                        <a href="index.php">
                            <img class="img-fluid for-white" src="assets/images/logo/full-white.png" alt="logo">
                        </a>
                        <div class="back-btn">
                            <i class="fa fa-angle-left"></i>
                        </div>
                        <div class="toggle-sidebar">
                            <i class="ri-apps-line status_toggle middle sidebar-toggle"></i>
                        </div>
                    </div>
                    <div class="logo-icon-wrapper">
                        <a href="index.php">
                            <img class="img-fluid main-logo main-white" src="assets/images/logo/1-white.png" alt="logo">
                            <img class="img-fluid main-logo main-dark" src="assets/images/logo/logo-white.png" alt="logo">
                        </a>
                    </div>

                    <?php include_once "nav.php"; ?>
                </div>
            </div>

            <div class="page-body">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card card-table">
                                <div class="card-body">
                                    <div class="title-header option-title">
                                        <h5>All Orders</h5>
                                    </div>

                                    <?php if ($deleteSuccess): ?>
                                        <div class="alert alert-success order-alert">Order deleted successfully.</div>
                                    <?php endif; ?>
                                    <?php if ($deleteError !== ''): ?>
                                        <div class="alert alert-danger order-alert"><?php echo e($deleteError); ?></div>
                                    <?php endif; ?>

                                    <div class="table-responsive table-product orders-table-wrap">
                                        <table class="table all-package theme-table" id="table_id">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Customer</th>
                                                    <th>Phone</th>
                                                    <th>Product</th>
                                                    <th>Qty</th>
                                                    <th>Total</th>
                                                    <th>Payment</th>
                                                    <th>Address</th>
                                                    <th>Status</th>
                                                    <th>Date</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if ($orders && $orders->num_rows > 0): ?>
                                                    <?php while ($row = $orders->fetch_assoc()): ?>
                                                        <?php
                                                        $total = (float) $row['product_price'] * (int) $row['quantity'];
                                                        $payment = $row['payment_method'] === 'online' ? 'Online' : 'COD';
                                                        ?>
                                                        <tr>
                                                            <td><?php echo (int) $row['id']; ?></td>
                                                            <td><strong><?php echo e($row['customer_name']); ?></strong></td>
                                                            <td><?php echo e($row['phone_number']); ?></td>
                                                            <td><?php echo e($row['product_name']); ?></td>
                                                            <td><?php echo (int) $row['quantity']; ?></td>
                                                            <td>Rs. <?php echo number_format($total, 2); ?></td>
                                                            <td><?php echo e($payment); ?></td>
                                                            <td><?php echo e($row['customer_address']); ?></td>
                                                            <td><span class="badge bg-warning text-dark"><?php echo e($row['order_status']); ?></span></td>
                                                            <td><?php echo e($row['created_at']); ?></td>
                                                            <td>
                                                                <form method="post" onsubmit="return confirm('Delete this order?');">
                                                                    <input type="hidden" name="order_id" value="<?php echo (int) $row['id']; ?>">
                                                                    <button type="submit" name="delete_order" class="btn btn-danger btn-sm">Delete</button>
                                                                </form>
                                                            </td>
                                                        </tr>
                                                    <?php endwhile; ?>
                                                <?php else: ?>
                                                    <tr>
                                                        <td colspan="11" class="text-center py-4">No orders found.</td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>

                                    <div class="orders-mobile">
                                        <?php if ($orders && $orders->num_rows > 0): ?>
                                            <?php $orders->data_seek(0); ?>
                                            <?php while ($row = $orders->fetch_assoc()): ?>
                                                <?php
                                                $total = (float) $row['product_price'] * (int) $row['quantity'];
                                                $payment = $row['payment_method'] === 'online' ? 'Online' : 'COD';
                                                ?>
                                                <div class="order-card">
                                                    <h6>#<?php echo (int) $row['id']; ?> - <?php echo e($row['product_name']); ?></h6>
                                                    <p><strong>Customer:</strong> <?php echo e($row['customer_name']); ?></p>
                                                    <p><strong>Phone:</strong> <?php echo e($row['phone_number']); ?></p>
                                                    <p><strong>Total:</strong> Rs. <?php echo number_format($total, 2); ?></p>
                                                    <p><strong>Payment:</strong> <?php echo e($payment); ?></p>
                                                    <p><strong>Address:</strong> <?php echo e($row['customer_address']); ?></p>
                                                    <p><strong>Date:</strong> <?php echo e($row['created_at']); ?></p>
                                                    <form method="post" onsubmit="return confirm('Delete this order?');">
                                                        <input type="hidden" name="order_id" value="<?php echo (int) $row['id']; ?>">
                                                        <button type="submit" name="delete_order" class="btn btn-danger btn-sm">Delete</button>
                                                    </form>
                                                </div>
                                            <?php endwhile; ?>
                                        <?php else: ?>
                                            <div class="order-card text-center">No orders found.</div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="container-fluid">
                    <?php include_once "footer.php"; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <script src="assets/js/bootstrap/bootstrap.bundle.min.js"></script>
    <script src="assets/js/icons/feather-icon/feather.min.js"></script>
    <script src="assets/js/icons/feather-icon/feather-icon.js"></script>
    <script src="assets/js/scrollbar/simplebar.js"></script>
    <script src="assets/js/scrollbar/custom.js"></script>
    <script src="assets/js/config.js"></script>
    <script src="assets/js/sidebar-menu.js"></script>
    <script src="assets/js/jquery.dataTables.js"></script>
    <script src="assets/js/custom-data-table.js"></script>
    <script src="assets/js/sidebareffect.js"></script>
    <script src="assets/js/script.js"></script>
</body>

</html>
<?php
if ($orders) {
    $orders->free();
}
$conn->close();
?>
